# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("Engine started for stress test...")

# COMMAND ----------

engine_key = "asset_liabilities_aggregation"
engine_config = env_config.get(f"engine.stresstest.{engine_key}")

# COMMAND ----------

from rda.engine.stresstest.stresstest import StressTest
stresstest = StressTest(env_config, spark, engine_config)

inputs = stresstest.read()
ga_b1_derive_df, ga_b1_derive_alda_pe_df = stresstest.step_asset_impact(inputs)

stresstest.unpersist_all()