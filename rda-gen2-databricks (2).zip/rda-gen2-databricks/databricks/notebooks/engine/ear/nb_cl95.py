# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("EAR engine CL95 started...")

# COMMAND ----------

engine_key = "cl95"
engine_config = env_config.get(f"engine.ear.{engine_key}")

# COMMAND ----------

from pyspark.sql import functions as F
from rda.engine.ear.cl95 import CL95
cl95 = CL95(env_config, spark, engine_config)

inputs = cl95.read()

losses_llp_region_df      = cl95.calculate_losses_llp_region(inputs)
losses_region_df          = cl95.calculate_losses_region_level(losses_llp_region_df)
losses_metric_df          = cl95.calculate_losses_metric_level(losses_region_df)
losses_company_df         = cl95.calculate_losses_company_level(losses_metric_df)
cl95_region_scenario_df   = cl95.calculate_cl95_region_scenario(losses_region_df)
cl95_company_scenario_df  = cl95.calculate_cl95_company_scenario(losses_company_df)
cl95_metric_company_df    = cl95.calculate_cl95_metric_company_scenario(losses_region_df, cl95_company_scenario_df)
cl95_region_company_df    = cl95.calculate_cl95_region_company_scenario(cl95_metric_company_df)

# COMMAND ----------

cl95.unpersist_all()
logger.info("EAR engine CL95 completed successfully")