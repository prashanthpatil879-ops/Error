# Databricks notebook source
# MAGIC %sql
# MAGIC create table gfdo_dev_catalog.gft_rda_curation.test(
# MAGIC     id int,
# MAGIC     name string,
# MAGIC     updateAt timestamp default current_timestamp()
# MAGIC )
# MAGIC using delta
# MAGIC TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported')
# MAGIC location 'abfss://rda-curated@cacdgftsuppriskadls.dfs.core.windows.net/test'

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into gfdo_dev_catalog.gft_rda_curation.test(id, name) values (5, 'test');

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from gfdo_dev_catalog.gft_rda_curation.test

# COMMAND ----------

# MAGIC %sql
# MAGIC update gfdo_dev_catalog.gft_rda_curation.test 
# MAGIC set name = 'test2'

# COMMAND ----------

# MAGIC %sql DESCRIBE DETAIL gfdo_dev_catalog.gft_rda_curation.test

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE gfdo_dev_catalog.gft_rda_curation.test
# MAGIC SET TBLPROPERTIES (delta.enableChangeDataFeed = true);

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history gfdo_dev_catalog.gft_rda_curation.test