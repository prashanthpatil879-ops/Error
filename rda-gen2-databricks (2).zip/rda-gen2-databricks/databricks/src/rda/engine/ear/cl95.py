from pyspark.sql import DataFrame
from pyspark.sql import functions as F, Window
from typing import NamedTuple
from rda.engine.base_step import RDABaseStep
import rda.utils.spark_utils as su


class CL95Inputs(NamedTuple):
    csm_flooring_pnl_df: DataFrame
    reinsurance_pnl_df: DataFrame
    nonha_losses_df: DataFrame
    ha_losses_df: DataFrame
    hierarchy_mapping_df: DataFrame


class CL95(RDABaseStep):

    METRICS = [
        "PNL_CSM_FLOORING_POSTTAX",
        "REINSURANCE_PNL",
        "LOSSES_NON_HA",
        "LOSSES_HA_LIAB",
        "LOSSES_HA_BOND",
        "LOSSES_MANUBANK",
    ]

    REPORTING_CURRENCY = "CAD"

    # AMOUNT sorted descending, rank 250 of 5000. Both the CL95 scenario and the
    # CL95 EaR are taken from this one row.
    CL95_RANK = 250

    REINSURANCE_LLPS = ["JHUSA USD-Rein SFG Reserve", "Reinsurance VA"]


    def read(self) -> CL95Inputs:
        inputs = self._step_config.inputs
        last_quarter_end_date = self._date_ctx.asDict().get('PREVIOUSQUARTERENDDATE', None)
        self._logger.info(f"Reading inputs for CL95 process, Quarter End Date: {last_quarter_end_date}")

        if last_quarter_end_date is None:
            raise ValueError(f"Invalid date context entry for PREVIOUSQUARTERENDDATE in: {self._date_ctx.asDict()}")

        reporting_date_filter = f"REPORTING_DATE='{last_quarter_end_date}'"

        input_dfs = CL95Inputs(
            csm_flooring_pnl_df = self._uc.read_latest(
                inputs.csm_flooring_pnl_final.table_name,
                filter=reporting_date_filter,
                watermark_col=inputs.csm_flooring_pnl_final.watermark_col
            ),
            reinsurance_pnl_df = self._uc.read_latest(
                inputs.reinsurance_pnl_final.table_name,
                filter=reporting_date_filter,
                watermark_col=inputs.reinsurance_pnl_final.watermark_col
            ),
            nonha_losses_df = self._uc.read_latest(
                inputs.nonha_losses_total.table_name,
                filter=reporting_date_filter,
                watermark_col=inputs.nonha_losses_total.watermark_col
            ),
            ha_losses_df = self._uc.read_latest(
                inputs.ha_ineff_dv01_losses_llp.table_name,
                filter=reporting_date_filter,
                watermark_col=inputs.ha_ineff_dv01_losses_llp.watermark_col
            ),
            hierarchy_mapping_df = self._uc.read_latest(
                inputs.irr_mapping_heirarchy_mapping_latest.table_name,
                watermark_col=inputs.irr_mapping_heirarchy_mapping_latest.watermark_col
            )
        )

        self.validate_inputs(input_dfs)
        return input_dfs


    def align_source(self, df, llp_col, currency_col, scenario_col, metric_map) -> DataFrame:
        """One source on the shape LLP + CURRENCY + SCENARIO + one column per
        metric. Metrics this source does not supply come through as 0."""
        columns = [
            F.trim(F.col(llp_col)).alias("LOWEST_LEVEL_PORTFOLIO_NAME"),
            F.upper(F.trim(F.col(currency_col))).alias("SECURITY_CURRENCY"),
            F.col(scenario_col).cast("int").alias("SCENARIO")
        ]

        for metric in self.METRICS:
            if metric in metric_map:
                columns.append( F.coalesce(F.col(metric_map[metric]).cast("double"), F.lit(0.0)).alias(metric) )
            else:
                columns.append( F.lit(0.0).alias(metric) )

        return df.select(*columns)


    def to_metric_rows(self, df) -> DataFrame:
        """The six metric columns turned into METRIC / AMOUNT rows."""
        metric_structs = [
            F.struct( F.lit(metric).alias("METRIC"), F.col(metric).alias("AMOUNT") )
            for metric in self.METRICS
        ]

        return (
            df
            .select(
                "LOWEST_LEVEL_PORTFOLIO_NAME", "SECURITY_CURRENCY", "SCENARIO",
                F.explode( F.array(*metric_structs) ).alias("m")
            )
            .select(
                "LOWEST_LEVEL_PORTFOLIO_NAME", "SECURITY_CURRENCY", "SCENARIO",
                F.col("m.METRIC").alias("METRIC"),
                F.col("m.AMOUNT").alias("AMOUNT")
            )
        )


    def cl95_pick(self, df, group_cols) -> DataFrame:
        """AMOUNT descending, rank 250. The scenario and the EaR both come from
        that row, so they always agree with each other."""
        cl95_window = Window.partitionBy(*group_cols).orderBy( F.col("AMOUNT").desc(), F.col("SCENARIO").asc() )

        return (
            df
            .withColumn("RNK", F.row_number().over(cl95_window))
            .filter( F.col("RNK") == self.CL95_RANK )
            .select(
                *group_cols,
                F.col("SCENARIO").alias("CL95_SCENARIO"),
                F.col("AMOUNT").alias("CL95_EAR")
            )
        )


    def region_mapping(self, hierarchy_mapping_df) -> DataFrame:
        """REGION and COMPANY_CODE per LLP, latest REPORTING_DATE_KEY only.
        Reinsurance for the two named LLPs, Surplus where PAR_STATUS_NAME says
        so, otherwise REGION_NAME with Bermuda folded into Asia."""
        latest_window = (
            Window
            .partitionBy( su.normalize_text(F.col("LOWEST_LEVEL_PORTFOLIO_NAME")) )
            .orderBy( F.col("REPORTING_DATE_KEY").desc() )
        )

        latest_df = (
            hierarchy_mapping_df
            .withColumn("RNK", F.dense_rank().over(latest_window))
            .filter( F.col("RNK") == 1 )
            .select(
                su.normalize_text(F.col("LOWEST_LEVEL_PORTFOLIO_NAME")).alias("MAP_LLP_KEY"),
                "REGION_NAME",
                "PAR_STATUS_NAME",
                "COMPANY_CODE"
            )
            .dropDuplicates(["MAP_LLP_KEY"])
        )

        reinsurance_keys = [su.normalize_text(F.lit(llp)) for llp in self.REINSURANCE_LLPS]

        region_df = (
            latest_df
            .withColumn(
                "REGION",
                F.when( F.col("MAP_LLP_KEY").isin(reinsurance_keys), F.lit("Reinsurance") )
                 .when( F.upper(F.trim(F.col("PAR_STATUS_NAME"))) == "SURPLUS", F.lit("Surplus") )
                 .when( F.col("REGION_NAME") == "Bermuda", F.lit("Asia") )
                 .otherwise( F.col("REGION_NAME") )
            )
        )

        return region_df.select("MAP_LLP_KEY", "REGION", "COMPANY_CODE")


    def calculate_losses_llp_region(self, inputs: CL95Inputs) -> DataFrame:
        self._logger.info("Starting CL95 - LLP and region level calculation process...")

        aligned_df = (
            self.align_source(
                inputs.csm_flooring_pnl_df, "LOWEST_LEVEL_PORTFOLIO_NAME", "CURRENCY_CODE", "SCENARIO_ID",
                {"PNL_CSM_FLOORING_POSTTAX": "PNL_CSM_FLOORING_POSTTAX"}
            )
            .unionByName( self.align_source(
                inputs.reinsurance_pnl_df, "LOWEST_LEVEL_PORTFOLIO_NAME", "CURRENCY_CODE", "SCENARIO_ID",
                {"REINSURANCE_PNL": "REINSURANCE_PNL"}
            ))
            .unionByName( self.align_source(
                inputs.nonha_losses_df, "LOWEST_LEVEL_PORTFOLIO_NAME", "ISSUE_CURRENCY", "SCENARIO",
                {"LOSSES_NON_HA": "AMOUNT"}
            ))
            .unionByName( self.align_source(
                inputs.ha_losses_df, "LOWEST_LEVEL_PORTFOLIO_NAME", "SECURITY_CURRENCY", "SCENARIO",
                {"LOSSES_HA_LIAB": "LOSSES_HA_LIAB", "LOSSES_HA_BOND": "LOSSES_HA_BOND", "LOSSES_MANUBANK": "LOSSES_MANUBANK"}
            ))
        )

        metric_rows_df = self.to_metric_rows(aligned_df)

        # Currencies and the HA per holding rows are summed away here.
        combined_df = (
            metric_rows_df
            .groupBy("LOWEST_LEVEL_PORTFOLIO_NAME", "SCENARIO", "METRIC")
            .agg( F.sum("AMOUNT").alias("AMOUNT") )
        )

        region_df = self.region_mapping(inputs.hierarchy_mapping_df)

        losses_llp_region_df = (
            combined_df.alias("c")
            .join(
                F.broadcast(region_df).alias("r"),
                on = su.normalize_text(F.col("c.LOWEST_LEVEL_PORTFOLIO_NAME")) == F.col("r.MAP_LLP_KEY"),
                how = "left"
            )
            .withColumn("CURRENCY_CD", F.lit(self.REPORTING_CURRENCY))
            .select(
                "c.LOWEST_LEVEL_PORTFOLIO_NAME", "r.REGION", "r.COMPANY_CODE",
                "CURRENCY_CD", "c.SCENARIO", "c.METRIC",
                F.coalesce(F.col("c.AMOUNT"), F.lit(0.0)).alias("AMOUNT")
            )
        )

        losses_llp_region_df = self.cache_df(losses_llp_region_df, "losses_llp_region_df")

        self.write(losses_llp_region_df.drop("COMPANY_CODE").withColumnRenamed("SCENARIO", "SCENARIO_ID"), self._step_config.step_losses_llp_region.table_name, self._step_config.step_losses_llp_region.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CL95 - LLP and region level calculation completed")
        return losses_llp_region_df


    def calculate_losses_region_level(self, losses_llp_region_df) -> DataFrame:
        self._logger.info("Starting CL95 - Region level calculation process...")

        losses_region_df = (
            losses_llp_region_df
            .groupBy("REGION", "COMPANY_CODE", "SCENARIO", "METRIC")
            .agg( F.sum("AMOUNT").alias("AMOUNT") )
        )

        losses_region_df = self.cache_df(losses_region_df, "losses_region_df")

        self.write(losses_region_df.drop("COMPANY_CODE").withColumnRenamed("SCENARIO", "SCENARIO_ID"), self._step_config.step_losses_region_level.table_name, self._step_config.step_losses_region_level.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CL95 - Region level calculation completed")
        return losses_region_df


    def calculate_losses_metric_level(self, losses_region_df) -> DataFrame:
        self._logger.info("Starting CL95 - Metric level calculation process...")

        losses_metric_df = (
            losses_region_df
            .groupBy("METRIC", "SCENARIO", "COMPANY_CODE")
            .agg( F.sum("AMOUNT").alias("AMOUNT") )
        )

        losses_metric_df = self.cache_df(losses_metric_df, "losses_metric_df")

        self.write(losses_metric_df.withColumnRenamed("SCENARIO", "SCENARIO_ID"), self._step_config.step_losses_metric_level.table_name, self._step_config.step_losses_metric_level.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CL95 - Metric level calculation completed")
        return losses_metric_df


    def calculate_losses_company_level(self, losses_metric_df) -> DataFrame:
        self._logger.info("Starting CL95 - Company level calculation process...")

        losses_company_df = (
            losses_metric_df
            .groupBy("COMPANY_CODE", "SCENARIO")
            .agg( F.sum("AMOUNT").alias("AMOUNT") )
        )

        losses_company_df = self.cache_df(losses_company_df, "losses_company_df")

        self.write(losses_company_df.withColumnRenamed("SCENARIO", "SCENARIO_ID"), self._step_config.step_losses_company_level.table_name, self._step_config.step_losses_company_level.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CL95 - Company level calculation completed")
        return losses_company_df


    def calculate_cl95_region_scenario(self, losses_region_df) -> DataFrame:
        self._logger.info("Starting CL95 - Region scenario calculation process...")

        region_totals_df = (
            losses_region_df
            .groupBy("REGION", "COMPANY_CODE", "SCENARIO")
            .agg( F.sum("AMOUNT").alias("AMOUNT") )
        )

        cl95_region_scenario_df = self.cl95_pick(region_totals_df, ["REGION"])

        cl95_region_scenario_df = self.cache_df(cl95_region_scenario_df, "cl95_region_scenario_df")

        self.write(cl95_region_scenario_df.withColumnRenamed("CL95_SCENARIO", "CL95_SCENARIO_ID"), self._step_config.step_cl95_region_scenario.table_name, self._step_config.step_cl95_region_scenario.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CL95 - Region scenario calculation completed")
        return cl95_region_scenario_df


    def calculate_cl95_company_scenario(self, losses_company_df) -> DataFrame:
        self._logger.info("Starting CL95 - Company scenario calculation process...")

        cl95_company_scenario_df = self.cl95_pick(losses_company_df, ["COMPANY_CODE"])

        cl95_company_scenario_df = self.cache_df(cl95_company_scenario_df, "cl95_company_scenario_df")

        self.write(cl95_company_scenario_df.withColumnRenamed("CL95_SCENARIO", "CL95_SCENARIO_ID"), self._step_config.step_cl95_company_scenario.table_name, self._step_config.step_cl95_company_scenario.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CL95 - Company scenario calculation completed")
        return cl95_company_scenario_df


    def calculate_cl95_metric_company_scenario(self, losses_region_df, cl95_company_scenario_df) -> DataFrame:
        self._logger.info("Starting CL95 - Metric by company scenario calculation process...")

        cl95_metric_company_df = (
            losses_region_df.alias("l")
            .join(
                F.broadcast(cl95_company_scenario_df).alias("c"),
                on = [
                    F.col("l.COMPANY_CODE") == F.col("c.COMPANY_CODE"),
                    F.col("l.SCENARIO") == F.col("c.CL95_SCENARIO")
                ],
                how = "inner"
            )
            .select(
                "l.REGION", "l.COMPANY_CODE", "l.METRIC",
                F.col("c.CL95_SCENARIO").alias("CL95_COMPANY_SCENARIO"),
                F.col("l.AMOUNT").alias("AMOUNT")
            )
        )

        cl95_metric_company_df = self.cache_df(cl95_metric_company_df, "cl95_metric_company_df")

        self.write(cl95_metric_company_df.withColumnRenamed("CL95_COMPANY_SCENARIO", "CL95_COMPANY_SCENARIO_ID"), self._step_config.step_cl95_metric_company_scenario.table_name, self._step_config.step_cl95_metric_company_scenario.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CL95 - Metric by company scenario calculation completed")
        return cl95_metric_company_df


    def calculate_cl95_region_company_scenario(self, cl95_metric_company_df) -> DataFrame:
        self._logger.info("Starting CL95 - Region at company scenario calculation process...")

        cl95_region_company_df = (
            cl95_metric_company_df
            .groupBy("REGION", "COMPANY_CODE", "CL95_COMPANY_SCENARIO")
            .agg( F.sum("AMOUNT").alias("AMOUNT") )
        )

        cl95_region_company_df = self.cache_df(cl95_region_company_df, "cl95_region_company_df")

        self.write(cl95_region_company_df.withColumnRenamed("CL95_COMPANY_SCENARIO", "CL95_COMPANY_SCENARIO_ID"), self._step_config.step_cl95_region_company_scenario.table_name, self._step_config.step_cl95_region_company_scenario.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CL95 - Region at company scenario calculation completed")
        return cl95_region_company_df
